console.log("index main fie");
// function click(){
// 	require("bundle-loader?lazy&name=my-chunk!./file.js")
// }